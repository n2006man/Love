document.getElementById('yesButton').addEventListener('click', () => {
    for (let i = 0; i < 20; i++) {
        const flower = document.createElement('div');
        flower.classList.add('flower');
        flower.style.left = `${Math.random() * 100}%`;
        flower.style.top = `${Math.random() * 100}%`;
        document.body.appendChild(flower);
    }
});